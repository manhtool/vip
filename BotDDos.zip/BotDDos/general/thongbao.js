const Discord = require("discord.js");

exports.run = async (client, message, args) => {

const ayarlar = require('../ayarlar.json');
var room = ayarlar.commandroom;

if (message.channel.id != room) {
	return;
  }

// Example command
if(!args[0]) {
	const embed1 = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle(' 🚕**Taxi Thông Báo **🚕 ')
	.setDescription(" Chào Tất Cả Người Dân Đang sinh sống và làm việc tại Thành phố San Fierro  \n ` Bắt đầu tuyển dụng nhân lực trực tiếp tại Taxi Company \n - - - Thời gian : \n Tối nay ngày 24/09/2022 \n Sẽ được phát loa trực tiếp \n Hoặc đến các khung giờ \n => 20h15 đến 21h30 \n - - - Yêu cầu : \n + Ăn mặc đầy đủ , lịch sự \n + Mang theo hồ sơ (( /thongtin + RolePlay )) \n + Đạt yêu cầu sinh sống tại thành phố trên 5 Năm (( Trên Level 5 ))\n  ` ")
	message.channel.send(embed1);
	return;
	}

}

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['Taxi'],
  permLevel: 0
}

exports.help = {
  name: 'Taxi',
  description: 'Nhat Anh#9855',
  usage: 'Taxi'
}
